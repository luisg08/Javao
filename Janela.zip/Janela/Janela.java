import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.GridLayout;

public class Janela extends JFrame{
	
	public Janela(){
		GridLayout layout = new GridLayout(3,2);
		setLayout(layout);
		
		JLabel lblNome = new JLabel("Nome: ");
		add(lblNome);
		
		JTextField txtNome = new JTextField();
		add(txtNome);
		
		JLabel lblIdade = new JLabel("Idade: ");
		add(lblIdade);
		
		JTextField txtIdade = new JTextField();
		add(txtIdade);
		
		JButton btCancel = new JButton("Cancelar");
		add(btCancel);
		
		JButton btOK = new JButton("OK");
		add(btOK);
		
		btOK.addActionListener( (e) -> {
			try{
				System.out.printf("Clicou %d\n", e.getWhen());
				Pessoa p = new Pessoa();
				p.setNome(txtNome.getText());
				p.setIdade(Integer.parseInt(txtIdade.getText()));
				System.out.printf("Nome: %s\n", p.getNome());
				System.out.printf("Idade: %d\n", p.getIdade());
			}catch(NumberFormatException ex){
				System.out.printf("Erro - Formato invalido\n");
				System.out.printf("%s\n", ex.getMessage());
				}
			catch(NumeroNegativoException ex){
				System.out.printf("Numero n�o pode ser negativo");
			}
		});
			
		setSize(300,150);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String args[]){
		new Janela();
	}
}
