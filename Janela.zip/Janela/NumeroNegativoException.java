public class NumeroNegativoException extends ArithmeticException{

}
