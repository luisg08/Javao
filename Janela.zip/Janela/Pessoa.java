public class Pessoa {

	private String nome;
	private int idade;
	
	public void setNome(String n){nome = n;}
	
	public void setIdade(int i){
		
		if(i<0){
		NumeroNegativoException e = new NumeroNegativoException();
		
		throw e;
		}
		idade = i;}
	
	public String getNome(){return nome;}
	
	public int getIdade(){return idade;}
}
